package com.cg.payroll.beans;

public class Employee {
	private int employeeId,basicsalary,totalsalary;
	private String firstName,lastName;
	public Employee(){
	super();
	}
	public Employee(int employeeId, int basicsalary, int totalsalary, String firstName, String lastName) {
		super();
		this.employeeId = employeeId;
		this.basicsalary = basicsalary;
		this.totalsalary = totalsalary;
		this.firstName = firstName;
		this.lastName = lastName;
	}
	public int getEmployeeId() {
		return employeeId;
	}
	public void setEmployeeId(int employeeId) {
		this.employeeId = employeeId;
	}
	public int getBasicSalary() {
		return basicsalary;
	}
	public void setBasicsalary(int basicsalary) {
		this.basicsalary = basicsalary;
	}
	public int getTotalsalary() {
		return totalsalary;
	}
	public void setTotalsalary(int totalsalary) {
		this.totalsalary = totalsalary;
	}
	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	public String getLastName() {
		return lastName;
	}
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	
}
