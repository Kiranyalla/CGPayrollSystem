package com.cg.payroll.main;

 class ABC {
int a,b,c;
public static int x;

}
