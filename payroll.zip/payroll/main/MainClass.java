package com.cg.payroll.main;


import com.cg.payroll.beans.Associate;

import com.cg.payroll.services.PayrollServicesImp;

public class MainClass {

	public static void main(String[] args) {
		
		PayrollServicesImp payrollServices = new PayrollServicesImp();
		int newId=payrollServices.acceptAssociateDetails("KIRAN", "YALLA", "kiran@gmail.com", "JAVA", "Analyst", "DJDKL65", 150000, 50000, 1000, 1000, 212, "Stand K", "SCGFDS546");
		System.out.println(newId);
		float y = payrollServices.calculateNetSalary(newId);
		System.out.println(y);
		Associate a1=payrollServices.getAssociateDetails(newId);
		System.out.println("Monthly tax= " +a1.getSalary().getMonthlyTax());
		//System.out.println(a1.toString());
		
		
	
	}
}
